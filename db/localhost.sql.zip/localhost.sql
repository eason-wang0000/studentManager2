-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2016 年 11 月 24 日 10:18
-- 服务器版本: 5.5.24-log
-- PHP 版本: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `smarty`
--
CREATE DATABASE `smarty` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `smarty`;

-- --------------------------------------------------------

--
-- 表的结构 `tb_account`
--

CREATE TABLE IF NOT EXISTS `tb_account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(16) NOT NULL,
  `pwd` varchar(16) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `tb_account`
--

INSERT INTO `tb_account` (`id`, `user`, `pwd`) VALUES
(1, 'admin', '1234');

-- --------------------------------------------------------

--
-- 表的结构 `tb_grade`
--

CREATE TABLE IF NOT EXISTS `tb_grade` (
  `xh` char(2) NOT NULL COMMENT '学号',
  `km` varchar(10) NOT NULL COMMENT '科目',
  `cj` int(11) DEFAULT NULL COMMENT '成绩'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `tb_grade`
--

INSERT INTO `tb_grade` (`xh`, `km`, `cj`) VALUES
('01', 'PHP', 77),
('01', 'JAVA', 70),
('02', 'PHP', 77),
('02', 'JAVA', 88),
('03', 'PHP', 97),
('03', 'JAVA', 97),
('04', 'PHP', 70),
('09', 'PHP', 100),
('12', 'PHP', 89),
('04', 'JAVA', 79),
('09', 'JAVA', 88),
('12', 'JAVA', 89),
('45', 'PHP', 80),
('01', 'jquery', 70);

-- --------------------------------------------------------

--
-- 表的结构 `tb_stuinf`
--

CREATE TABLE IF NOT EXISTS `tb_stuinf` (
  `xh` varchar(2) NOT NULL COMMENT '学号',
  `xm` varchar(10) NOT NULL COMMENT '姓名',
  `sex` bit(1) NOT NULL DEFAULT b'0' COMMENT '性别，0为男，1为女',
  `bj` varchar(20) NOT NULL COMMENT '班级',
  PRIMARY KEY (`xh`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `tb_stuinf`
--

INSERT INTO `tb_stuinf` (`xh`, `xm`, `sex`, `bj`) VALUES
('01', 'A', b'0', '通信1501'),
('02', 'B', b'1', '通信1502'),
('03', 'C', b'0', '软件1507'),
('04', 'D', b'1', '软件1507'),
('05', 'E', b'0', '网络1511'),
('06', 'F', b'1', '网络1511'),
('07', 'G', b'1', '广告1512'),
('08', 'H', b'1', '广告1512'),
('09', 'wyx', b'0', '软件1507'),
('12', '小小', b'1', '软件1507'),
('16', '小㊣', b'0', '通信1503'),
('45', 'w朕', b'0', '软件1507');

-- --------------------------------------------------------

--
-- 表的结构 `tb_subject`
--

CREATE TABLE IF NOT EXISTS `tb_subject` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kmname` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `tb_subject`
--

INSERT INTO `tb_subject` (`id`, `kmname`) VALUES
(1, 'PHP'),
(2, 'JAVA'),
(3, 'jquery');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
